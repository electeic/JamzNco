# Grubmate - Jamila Applications Incorporated


Grubmate is a crowdsourcing app that allows for users to request and post food inquiries for the convenience of the user. The system will allow for users to post and request meals from fellow friends and classmates. 


1. Steps to Run the App
	1. Need Android Studio in order for the app to run
	2. Emulator used: Nexus 5 API 25
	3. Run by going to Run 'app'
    4. Click the Login via Facebook button (if this is not your first time logging in and you did not log out before closing the app, then when the app reopens you must first logout before you log back in)
    5. The resulting main screen will show all the posts that are visible to you (your Facebook friends' posts)
    6. Click on any post you want to go to the detailed post view. You may now request food from the detailed view page.
    7. From the main page, click on the small red icon on the bottom right to visit the menu page. From here, you can visit any of the links to go to any of the respective pages. All pages should have a menu button at the same place to re-visit the home page or any of the respective pages. 



2. Other Considerations
	1. In order to run Grubmate, a Facebook account is needed


3. Other bugs
	1. Search is not implemented, the database for groups has some bugs.
