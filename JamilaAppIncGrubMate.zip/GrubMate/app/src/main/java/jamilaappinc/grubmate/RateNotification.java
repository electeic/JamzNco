package jamilaappinc.grubmate;

/**
 * Created by melod on 10/16/2017.
 */

public class RateNotification extends Notification {
    public RateNotification(String mFromUser, String mAboutPost, String mToUser){
        super(mFromUser,mAboutPost,mToUser);
    }
}

