package jamilaappinc.grubmate;

/**
 * Created by melod on 10/14/2017.
 */

public class RequestedNotification extends Notification {
    public RequestedNotification(String mFromUser, String mAboutPost, String mToUser){
        super(mFromUser,mAboutPost,mToUser);
    }
}
