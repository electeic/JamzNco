package jamilaappinc.grubmate;

/**
 * Created by melod on 10/14/2017.
 */

public class AcceptedNotification extends Notification {
    public AcceptedNotification(String mFromUser, String mAboutPost, String mToUser){
        super(mFromUser,mAboutPost,mToUser);
    }
}
