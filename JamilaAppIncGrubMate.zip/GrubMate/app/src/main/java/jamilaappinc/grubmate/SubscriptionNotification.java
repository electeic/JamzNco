package jamilaappinc.grubmate;

/**
 * Created by melod on 10/14/2017.
 */

public class SubscriptionNotification extends Notification {
    public SubscriptionNotification(String mFromUser, String mAboutPost, String mToUser){
        super(mFromUser,mAboutPost,mToUser);
    }
}
